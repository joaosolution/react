import "./Footer.css";

const Footer = () => {
  return (
    <footer id="footer">
      <p>ReactGram &copy; 2022</p>
    </footer>
  );
};

export default Footer;
