import "./MyComponent.css";

const MyComponent = () => {
  return (
    <div>
      <h1>CSS de componente</h1>
      <p>Este parágrafo vai ter um estilo</p>
    </div>
  );
};

export default MyComponent;
