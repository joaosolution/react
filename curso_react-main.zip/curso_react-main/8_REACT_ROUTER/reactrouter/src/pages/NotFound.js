import React from "react";

const NotFound = () => {
  return (
    <div>
      <h1>404</h1>
      <p>Não há nada aqui =(</p>
    </div>
  );
};

export default NotFound;
