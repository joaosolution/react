import MyComponent from "./MyComponent";

const FirstComponent = () => {
  // Um comentário
  return (
    <div>
      {/* Um comentário no JSX */}
      <h1>Título</h1>
      <p className="text">Testando alguma classe</p>
      <MyComponent />
    </div>
  );
};

export default FirstComponent;
