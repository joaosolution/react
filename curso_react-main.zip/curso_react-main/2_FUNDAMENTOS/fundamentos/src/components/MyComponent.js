const MyComponent = () => {
  return (
    <div>
      <h2>Estou sendo reaproveitado em vários lugares!</h2>
    </div>
  );
};

export default MyComponent;
