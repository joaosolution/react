const MessageState = ({ msg }) => {
  return (
    <div>
      <p>A mensagem é: {msg}</p>
    </div>
  );
};

export default MessageState;
